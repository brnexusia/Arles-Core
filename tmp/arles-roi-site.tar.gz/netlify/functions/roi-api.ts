import type { Context, Config } from "@netlify/functions";

function isAllowedPath(action: string) {
  return ["auth", "logout", "list", "save", "config", "config-save"].includes(action);
}

async function digest(value: string) {
  const bytes = new TextEncoder().encode(`${value}::arles-roi-session`);
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function cookieValue(req: Request, key: string) {
  const cookie = req.headers.get("cookie") || "";
  const found = cookie.split(";").map((x) => x.trim()).find((x) => x.startsWith(`${key}=`));
  return found ? decodeURIComponent(found.slice(key.length + 1)) : "";
}

function json(data: unknown, status = 200, extraHeaders: Record<string,string> = {}) {
  return new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...extraHeaders } });
}

export default async (req: Request, context: Context) => {
  const action = new URL(req.url).pathname.split("/").filter(Boolean).pop() || "";
  if (!isAllowedPath(action)) return json({ error: "Rota inválida" }, 404);

  const pin = Netlify.env.get("ROI_ACCESS_PIN") || "";
  if (!pin) return json({ error: "ROI_ACCESS_PIN não configurado" }, 500);
  const expectedSession = await digest(pin);

  if (action === "auth") {
    if (req.method !== "POST") return json({ error: "Método não permitido" }, 405);
    const body = await req.json().catch(() => ({})) as { pin?: string };
    if (String(body.pin || "") !== pin) return json({ error: "PIN inválido" }, 401);
    return json({ ok: true }, 200, { "set-cookie": `roi_session=${expectedSession}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=2592000` });
  }

  if (action === "logout") {
    return json({ ok: true }, 200, { "set-cookie": "roi_session=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0" });
  }

  const session = cookieValue(req, "roi_session");
  if (!session || session !== expectedSession) return json({ error: "Não autorizado" }, 401);

  const base = (Netlify.env.get("ROI_N8N_BASE_URL") || "").replace(/\/$/, "");
  if (!base) return json({ error: "ROI_N8N_BASE_URL não configurado" }, 500);

  const method = action === "list" || action === "config" ? "GET" : "POST";
  if (req.method !== method) return json({ error: "Método não permitido" }, 405);

  const init: RequestInit = { method, headers: { "content-type": "application/json" } };
  if (method === "POST") init.body = await req.text();

  try {
    const upstream = await fetch(`${base}/${action}`, init);
    const body = await upstream.text();
    return new Response(body || JSON.stringify({ ok: upstream.ok }), {
      status: upstream.status,
      headers: { "content-type": upstream.headers.get("content-type") || "application/json; charset=utf-8", "cache-control": "no-store" },
    });
  } catch (error) {
    return json({ error: "Falha ao conectar ao backend de dados", detail: String(error) }, 502);
  }
};

export const config: Config = {
  path: ["/api/roi/auth", "/api/roi/logout", "/api/roi/list", "/api/roi/save", "/api/roi/config", "/api/roi/config-save"],
};
