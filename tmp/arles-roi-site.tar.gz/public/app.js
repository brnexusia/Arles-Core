const API = '/api/roi';
const state = { rows: [], config: {}, period: 'today', editingId: null };
const $ = (id) => document.getElementById(id);
const money = (v) => new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(Number(v)||0);
const num = (v) => Number(String(v ?? 0).replace(',','.')) || 0;
const pct = (v) => `${(Number(v)||0).toFixed(1).replace('.',',')}%`;
const fmtDate = (v) => { if(!v) return '—'; const [y,m,d]=String(v).slice(0,10).split('-'); return y&&m&&d?`${d}/${m}/${y}`:v; };
const todayISO = () => new Date().toLocaleDateString('en-CA',{timeZone:'America/Bahia'});
const addDays = (iso, days) => { const d=new Date(`${iso}T12:00:00-03:00`); d.setDate(d.getDate()+Number(days||0)); return d.toLocaleDateString('en-CA',{timeZone:'America/Bahia'}); };
const daysBetween = (a,b) => Math.ceil((new Date(`${b}T12:00:00-03:00`)-new Date(`${a}T12:00:00-03:00`))/86400000);

function toast(msg, error=false){ const el=$('toast'); el.textContent=msg; el.style.borderColor=error?'rgba(255,107,116,.55)':'rgba(56,217,150,.4)'; el.classList.remove('hidden'); clearTimeout(toast.t); toast.t=setTimeout(()=>el.classList.add('hidden'),2600); }
function setSync(mode,text){ const dot=$('syncDot'); dot.className='dot'+(mode==='loading'?' loading':mode==='error'?' error':''); $('syncText').textContent=text; }
async function request(path, options={}){
  const res=await fetch(`${API}/${path}`,{headers:{'Content-Type':'application/json',...(options.headers||{})},...options});
  if(res.status===401) throw Object.assign(new Error('unauthorized'),{status:401});
  const text=await res.text(); let data={}; try{data=text?JSON.parse(text):{};}catch{data={raw:text};}
  if(!res.ok) throw new Error(data.error||data.message||`Erro ${res.status}`);
  return data;
}
function rowsFrom(data){ return Array.isArray(data)?data:(Array.isArray(data.rows)?data.rows:[]); }
function normalizeRow(r){
  return {
    id:String(r.ID||''), date:String(r.Data||''), offer:String(r.Oferta||''), channel:String(r.Canal||''), adSpend:num(r['Gasto Ads']), sales:num(r.Vendas), revenue:num(r['Faturamento Bruto']), pix:num(r.PIX), card:num(r.Cartao), cardFeePct:num(r['Taxa Cartao %']), cardFeeValue:num(r['Taxa Cartao R$']), otherCosts:num(r['Outros Custos']), netRevenue:num(r['Receita Liquida']), profit:num(r.Lucro), roas:num(r.ROAS), roi:num(r['ROI %']), cpa:num(r.CPA), ticket:num(r['Ticket Medio']), cardReceivable:num(r['Recebivel Cartao']), dueDate:String(r['Data Recebimento']||''), status:String(r['Status Recebivel']||''), notes:String(r.Observacoes||''), createdAt:String(r['Criado em']||'')
  };
}
function configFrom(rows){ const out={}; rows.forEach(r=>out[String(r.Chave||'')]=num(r.Valor)); return out; }
async function loadAll(){
  setSync('loading','Atualizando Sheets…');
  try{
    const [entries,configs]=await Promise.all([request('list'),request('config')]);
    state.rows=rowsFrom(entries).map(normalizeRow).filter(r=>r.id);
    state.config=configFrom(rowsFrom(configs));
    applyConfigDefaults(); render(); setSync('ok','Sincronizado com Sheets');
  }catch(e){ if(e.status===401){showLock();return;} setSync('error','Erro de sincronização'); toast(e.message,true); }
}
function applyConfigDefaults(){
  const days=state.config.cartao_dias_liquidacao ?? 15;
  const fee=state.config.taxa_cartao_padrao ?? 0;
  if(!$('cardFee').dataset.touched) $('cardFee').value=fee;
  $('simDays').value=days; $('setCardDays').value=days; $('setCardFee').value=fee; $('setInitialCash').value=state.config.capital_giro_inicial??0; $('setMetaRoas').value=state.config.meta_roas??2; $('setMetaRoi').value=state.config.meta_roi_pct??50;
}
function getFiltered(){
  const now=todayISO();
  return state.rows.filter(r=>{
    if(state.period==='all') return true;
    if(state.period==='today') return r.date===now;
    const diff=daysBetween(r.date,now);
    if(state.period==='7d') return diff>=0&&diff<7;
    if(state.period==='30d') return diff>=0&&diff<30;
    if(state.period==='month') return r.date.slice(0,7)===now.slice(0,7);
    return true;
  });
}
function summary(rows){
  const s=rows.reduce((a,r)=>{a.ad+=r.adSpend;a.sales+=r.sales;a.rev+=r.revenue;a.profit+=r.profit;a.card+=r.card;a.fees+=r.cardFeeValue;return a;},{ad:0,sales:0,rev:0,profit:0,card:0,fees:0});
  s.roas=s.ad?s.rev/s.ad:0; s.roi=s.ad?s.profit/s.ad*100:0; s.cpa=s.sales?s.ad/s.sales:0; s.ticket=s.sales?s.rev/s.sales:0; return s;
}
function renderMetrics(rows){
  const s=summary(rows); const metaRoas=state.config.meta_roas??2, metaRoi=state.config.meta_roi_pct??50;
  const cards=[
    ['Gasto Ads',money(s.ad),'Investimento no período',''],['Faturamento',money(s.rev),`${s.sales} venda${s.sales===1?'':'s'}`,'info'],['Lucro',money(s.profit),'Após mídia, taxas e custos',s.profit>=0?'good':'bad'],['ROAS',`${s.roas.toFixed(2).replace('.',',')}x`,`Meta ${metaRoas}x`,s.roas>=metaRoas?'good':'bad'],['ROI',pct(s.roi),`Meta ${metaRoi}%`,s.roi>=metaRoi?'good':'bad'],['CPA',money(s.cpa),'Custo por venda',''],['Ticket médio',money(s.ticket),'Faturamento ÷ vendas',''],['Vendas',String(s.sales),'Quantidade no período',''],['Taxa cartão',money(s.fees),'Custo total de cartão',''],['% no cartão',pct(s.rev?s.card/s.rev*100:0),'Impacto no caixa','']
  ];
  $('metrics').innerHTML=cards.map(([l,v,h,c])=>`<article class="metric ${c}"><span>${l}</span><strong>${v}</strong><small>${h}</small></article>`).join('');
}
function cashSummary(){
  const today=todayISO(), initial=state.config.capital_giro_inicial??0;
  let cash=initial, locked=0; const payouts=[];
  state.rows.forEach(r=>{
    cash += r.pix;
    cash -= r.adSpend + r.otherCosts;
    if(r.card>0){ const netCard=Math.max(0,r.card-r.cardFeeValue); if(r.dueDate && r.dueDate<=today) cash+=netCard; else {locked+=netCard;if(r.dueDate) payouts.push({date:r.dueDate,value:netCard});} }
  });
  const last7=state.rows.filter(r=>{const d=daysBetween(r.date,today);return d>=0&&d<7;});
  const avgAd=last7.reduce((s,r)=>s+r.adSpend,0)/7; const runway=avgAd>0?cash/avgAd:Infinity;
  payouts.sort((a,b)=>a.date.localeCompare(b.date)); return {cash,locked,runway,next:payouts[0]};
}
function renderCash(){
  const c=cashSummary(); $('cashAvailable').textContent=money(c.cash); $('cashLocked').textContent=money(c.locked); $('runwayDays').textContent=Number.isFinite(c.runway)?`${Math.max(0,c.runway).toFixed(1).replace('.',',')} dias`:'Sem gasto recente'; $('nextPayout').textContent=c.next?`${fmtDate(c.next.date)} · ${money(c.next.value)}`:'—';
  const badge=$('cashHealth'); if(c.cash<0){badge.textContent='Caixa negativo';badge.className='badge bad';} else if(Number.isFinite(c.runway)&&c.runway<7){badge.textContent='Giro apertado';badge.className='badge warn';} else {badge.textContent='Caixa saudável';badge.className='badge good';}
}
function renderTable(rows){
  const q=$('searchInput').value.trim().toLowerCase(); const filtered=rows.filter(r=>!q||`${r.offer} ${r.channel}`.toLowerCase().includes(q)).sort((a,b)=>b.date.localeCompare(a.date)||b.createdAt.localeCompare(a.createdAt));
  $('entriesBody').innerHTML=filtered.map(r=>`<tr><td>${fmtDate(r.date)}</td><td><strong>${escapeHtml(r.offer)}</strong><br><span class="muted tiny">${escapeHtml(r.channel)}</span></td><td>${money(r.adSpend)}</td><td>${r.sales}</td><td>${money(r.revenue)}</td><td><strong class="${r.profit>=0?'profit':'loss'}">${money(r.profit)}</strong></td><td>${r.roas.toFixed(2).replace('.',',')}x</td><td>${money(r.card)}</td><td>${r.card?fmtDate(r.dueDate):'—'}</td><td><button class="row-action" data-edit="${escapeHtml(r.id)}">Editar</button></td></tr>`).join('');
  $('emptyState').classList.toggle('hidden',filtered.length>0);
  document.querySelectorAll('[data-edit]').forEach(b=>b.addEventListener('click',()=>startEdit(b.dataset.edit)));
}
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function render(){const rows=getFiltered();renderMetrics(rows);renderCash();renderTable(rows);drawChart();calcEntry();calcSimulator();}
function calcEntry(){
  const ad=num($('adSpend').value), sales=num($('sales').value), rev=num($('revenue').value), card=num($('card').value), feePct=num($('cardFee').value), other=num($('otherCosts').value); const fee=card*feePct/100, net=rev-fee-other, profit=net-ad, roas=ad?rev/ad:0, roi=ad?profit/ad*100:0, cpa=sales?ad/sales:0; const due=card?addDays($('date').value||todayISO(),state.config.cartao_dias_liquidacao??15):'';
  $('calcCardFee').textContent=money(fee); $('calcProfit').textContent=money(profit); $('calcProfit').style.color=profit>=0?'var(--green)':'var(--red)'; $('calcRoas').textContent=`${roas.toFixed(2).replace('.',',')}x`; $('calcRoi').textContent=pct(roi); $('calcCpa').textContent=money(cpa); $('calcDueDate').textContent=due?fmtDate(due):'—';
  return {ad,sales,rev,card,feePct,other,fee,net,profit,roas,roi,cpa,due,ticket:sales?rev/sales:0};
}
async function saveEntry(e){
  e.preventDefault(); const c=calcEntry(), id=$('entryId').value||crypto.randomUUID(); const card=num($('card').value), pix=num($('pix').value); const payload={id,data:$('date').value,oferta:$('offer').value.trim(),canal:$('channel').value,gastoAds:c.ad,vendas:c.sales,faturamentoBruto:c.rev,pix,cartao:card,taxaCartaoPct:c.feePct,taxaCartaoValor:c.fee,outrosCustos:c.other,receitaLiquida:c.net,lucro:c.profit,roas:c.roas,roiPct:c.roi,cpa:c.cpa,ticketMedio:c.ticket,recebivelCartao:Math.max(0,card-c.fee),dataRecebimento:c.due,statusRecebivel:card?(c.due<=todayISO()?'Recebido':'Pendente'):'Recebido',observacoes:$('notes').value.trim(),criadoEm:new Date().toISOString()};
  $('saveEntryBtn').disabled=true; $('saveEntryBtn').textContent='Salvando…';
  try{await request('save',{method:'POST',body:JSON.stringify(payload)});toast(state.editingId?'Lançamento atualizado.':'Lançamento salvo no Sheets.');resetForm();await loadAll();}catch(err){toast(err.message,true);}finally{$('saveEntryBtn').disabled=false;$('saveEntryBtn').textContent='Salvar no Google Sheets';}
}
function startEdit(id){const r=state.rows.find(x=>x.id===id);if(!r)return;state.editingId=id;$('entryId').value=r.id;$('date').value=r.date;$('offer').value=r.offer;$('channel').value=r.channel;$('adSpend').value=r.adSpend;$('sales').value=r.sales;$('revenue').value=r.revenue;$('pix').value=r.pix;$('card').value=r.card;$('cardFee').value=r.cardFeePct;$('otherCosts').value=r.otherCosts;$('notes').value=r.notes;$('formTitle').textContent='Editar lançamento';$('cancelEditBtn').classList.remove('hidden');calcEntry();window.scrollTo({top:$('entryForm').getBoundingClientRect().top+window.scrollY-90,behavior:'smooth'});}
function resetForm(){state.editingId=null;$('entryForm').reset();$('entryId').value='';$('date').value=todayISO();$('channel').value='Meta Ads';$('cardFee').value=state.config.taxa_cartao_padrao??0;$('formTitle').textContent='Registrar operação';$('cancelEditBtn').classList.add('hidden');calcEntry();}
function calcSimulator(){
  const budget=num($('simBudget').value), cpa=Math.max(.01,num($('simCpa').value)), ticket=num($('simTicket').value), cardPct=Math.min(100,Math.max(0,num($('simCardPct').value)))/100, costSale=num($('simCostPerSale').value), days=num($('simDays').value), feePct=state.config.taxa_cartao_padrao??0; const sales=budget/cpa, rev=sales*ticket, cardGross=rev*cardPct, pix=rev-cardGross, fee=cardGross*feePct/100, variable=sales*costSale, profit=rev-fee-variable-budget, dailyCashBurn=Math.max(0,budget+variable-pix), working=dailyCashBurn*days, pipeline=Math.max(0,cardGross-fee)*days;
  $('simSales').textContent=sales.toFixed(1).replace('.',',');$('simRevenue').textContent=money(rev);$('simProfit').textContent=money(profit);$('simRoas').textContent=`${(budget?rev/budget:0).toFixed(2).replace('.',',')}x`;$('simWorkingCapital').textContent=money(working);$('simPipeline').textContent=money(pipeline);
}
function drawChart(){
  const canvas=$('trendChart'), ctx=canvas.getContext('2d'); const ratio=window.devicePixelRatio||1, w=canvas.clientWidth||600,h=210; canvas.width=w*ratio;canvas.height=h*ratio;ctx.scale(ratio,ratio);ctx.clearRect(0,0,w,h);
  const dates=[]; for(let i=13;i>=0;i--) dates.push(addDays(todayISO(),-i)); const data=dates.map(d=>{const rs=state.rows.filter(r=>r.date===d);return {d,rev:rs.reduce((s,r)=>s+r.revenue,0),ad:rs.reduce((s,r)=>s+r.adSpend,0)}}); const max=Math.max(1,...data.flatMap(x=>[x.rev,x.ad])); const pad={l:38,r:14,t:12,b:26}; const iw=w-pad.l-pad.r,ih=h-pad.t-pad.b; ctx.strokeStyle='#242a33';ctx.lineWidth=1;for(let i=0;i<4;i++){const y=pad.t+ih*i/3;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();}
  const line=(key,color)=>{ctx.strokeStyle=color;ctx.lineWidth=2;ctx.beginPath();data.forEach((x,i)=>{const px=pad.l+iw*(i/(data.length-1)),py=pad.t+ih-(x[key]/max)*ih;i?ctx.lineTo(px,py):ctx.moveTo(px,py)});ctx.stroke();}; line('rev','#7c6cff');line('ad','#38d996'); ctx.fillStyle='#788391';ctx.font='10px system-ui';ctx.fillText('Faturamento',pad.l,10);ctx.fillStyle='#7c6cff';ctx.fillRect(pad.l+68,4,14,3);ctx.fillStyle='#788391';ctx.fillText('Ads',pad.l+92,10);ctx.fillStyle='#38d996';ctx.fillRect(pad.l+113,4,14,3);[0,4,8,13].forEach(i=>{ctx.fillStyle='#687383';ctx.fillText(fmtDate(data[i].d).slice(0,5),pad.l+iw*(i/13)-12,h-7)});
}
async function saveSettings(e){e.preventDefault();const items=[['cartao_dias_liquidacao',num($('setCardDays').value),'Prazo padrao para recebimento das vendas no cartao'],['taxa_cartao_padrao',num($('setCardFee').value),'Taxa percentual padrao do cartao'],['capital_giro_inicial',num($('setInitialCash').value),'Caixa disponivel no inicio do controle'],['meta_roas',num($('setMetaRoas').value),'Meta minima de ROAS'],['meta_roi_pct',num($('setMetaRoi').value),'Meta minima de ROI percentual']];try{await Promise.all(items.map(([chave,valor,descricao])=>request('config-save',{method:'POST',body:JSON.stringify({chave,valor,descricao})})));toast('Configurações salvas no Sheets.');closeSettings();await loadAll();}catch(err){toast(err.message,true);}}
function openSettings(){$('settingsModal').classList.remove('hidden');applyConfigDefaults();}function closeSettings(){$('settingsModal').classList.add('hidden');}
function showLock(){$('app').classList.add('hidden');$('lockScreen').classList.remove('hidden');$('pinInput').focus();}function showApp(){$('lockScreen').classList.add('hidden');$('app').classList.remove('hidden');}
async function login(e){e.preventDefault();$('loginError').classList.add('hidden');try{await request('auth',{method:'POST',body:JSON.stringify({pin:$('pinInput').value})});showApp();resetForm();await loadAll();}catch{$('loginError').classList.remove('hidden');}}
async function logout(){try{await request('logout',{method:'POST',body:'{}'});}catch{}showLock();}
function bind(){
  $('loginForm').addEventListener('submit',login);$('logoutBtn').addEventListener('click',logout);$('refreshBtn').addEventListener('click',loadAll);$('entryForm').addEventListener('submit',saveEntry);$('cancelEditBtn').addEventListener('click',resetForm);$('searchInput').addEventListener('input',()=>renderTable(getFiltered()));$('openSettingsBtn').addEventListener('click',openSettings);$('settingsForm').addEventListener('submit',saveSettings);document.querySelectorAll('[data-close-settings]').forEach(x=>x.addEventListener('click',closeSettings));
  $('periodTabs').addEventListener('click',(e)=>{if(!e.target.dataset.period)return;state.period=e.target.dataset.period;document.querySelectorAll('#periodTabs button').forEach(b=>b.classList.toggle('active',b===e.target));render();});
  ['adSpend','sales','revenue','pix','card','cardFee','otherCosts','date'].forEach(id=>$(id).addEventListener('input',calcEntry));$('cardFee').addEventListener('input',()=>{$('cardFee').dataset.touched='1'});['simBudget','simCpa','simTicket','simCardPct','simCostPerSale','simDays'].forEach(id=>$(id).addEventListener('input',calcSimulator));window.addEventListener('resize',drawChart);
}
async function boot(){bind();$('date').value=todayISO();try{await request('config');showApp();resetForm();await loadAll();}catch(e){showLock();}}
boot();
